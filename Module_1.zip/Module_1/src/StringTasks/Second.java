package StringTasks;

public class Second {
	public static void main(String[] args) {
		String s="java standard edition";
		System.out.println(s.c);
	}
	
	
	
}
