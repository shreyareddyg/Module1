package StringTasks;

public class Fourth {
	public static void main(String[] args) {
		String s= "Shubham";
		System.out.println(s.endsWith("ma"));
	}
}
