package lab2_exercise_1;

public class CD {
	
	private String director;
	private String genre;
	private String yearofrelase;
	
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getYearofrelase() {
		return yearofrelase;
	}
	public void setYearofrelase(String yearofrelase) {
		this.yearofrelase = yearofrelase;
	}

}
