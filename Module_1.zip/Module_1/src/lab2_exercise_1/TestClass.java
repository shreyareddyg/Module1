package lab2_exercise_1;

public class TestClass {

}
