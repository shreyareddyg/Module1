package lab1_exercise_3;

public class NumberIncreasing {
	public static void main(String[] args) {
		
	}
	
	static boolean checkNumber(int n) {
		for(int i=0;i<=n;i++)
		{
		}
		return false;
		//return false;
	}
}
