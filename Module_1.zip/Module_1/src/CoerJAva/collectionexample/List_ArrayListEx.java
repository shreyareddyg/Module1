package collectionexample;
import java.util.*;

public class List_ArrayListEx {
	public static void main(String[] args) {

		HashSet al = new HashSet();
		
		al.add("Shubhma");
		al.add(12314);
		al.add('z');
		al.add("Shubhma");
	
		System.out.println(al);
	}
}
